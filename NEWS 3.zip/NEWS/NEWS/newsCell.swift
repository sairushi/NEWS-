//
//  newsCell.swift
//  NEWS
//
//  Created by mymac on 31/07/19.
//  Copyright © 2019 mymac. All rights reserved.
//

import UIKit

class newsCell: UITableViewCell {
    @IBOutlet weak var imageview: UIImageView!
    
    @IBOutlet weak var dateTime: UILabel!
    @IBOutlet weak var author: UILabel!
    @IBOutlet weak var dsc: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var cellView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }



}
