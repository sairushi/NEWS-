//
//  ViewController.swift
//  NEWS
//
//  Created by mymac on 31/07/19.
//  Copyright © 2019 mymac. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

var newsReader = [News]()
    @IBOutlet weak var tableview: UITableView!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        newsFetching()
        
    }

    
    func   newsFetching(){
        
        guard let url = URL(string: "https://newsapi.org/v2/top-headlines?sources=google-news-in&apiKey=3076c9e562154f18bc99c26ca9517f09") else {return}
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                error == nil else {
                    print(error?.localizedDescription ?? "Response Error")
                    return }
            do{
                
                let decoder = JSONDecoder()
                let newsData = try decoder.decode(articleList.self, from: dataResponse)
                self.newsReader = newsData.articles
                
                print(newsData.articles)

                DispatchQueue.main.async {
                    self.tableview.reloadData()
                }
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        task.resume()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsReader.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell", for: indexPath) as! newsCell
        cell.title.text = newsReader[indexPath.row].title
        cell.dsc.text = newsReader[indexPath.row].description
        cell.author.text = newsReader[indexPath.row].author
         cell.dateTime.text =  newsReader[indexPath.row].publishedAt
        cell.backgroundColor = UIColor.clear
        cell.cellView.layer.borderColor = UIColor.lightGray.cgColor
        
        if let imageURL = URL(string: newsReader[indexPath.row].urlToImage ?? "No Image") {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.imageview.image = image
                    }
                }
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       let  url  = URL(string: newsReader[indexPath.row].url)
        if url != nil{
            UIApplication.shared.open(url!, options: [:], completionHandler: nil)
            
        }
    }
}

